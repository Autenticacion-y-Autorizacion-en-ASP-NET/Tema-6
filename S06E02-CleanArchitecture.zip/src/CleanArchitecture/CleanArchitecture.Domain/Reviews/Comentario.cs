namespace CleanArchitecture.Domain.Reviews;


public sealed record Comentario(string Value);